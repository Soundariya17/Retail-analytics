# Retail Analytics Project

## Overview
This project demonstrates end-to-end data analysis for a fictional retail company using:
- **Python** for data cleaning and transformation
- **SQL** for database schema and queries
- **Power BI** for interactive dashboards

## Folder Structure
```
Retail-Analytics-Project/
├── data/                  # Raw and cleaned datasets
├── python/                # Data cleaning script
├── sql/                   # Database schema and queries
├── powerbi/               # Power BI dashboard (manual work)
```

## How to Use
1. Run `data_cleaning.py` to prepare the dataset.
2. Use `schema.sql` to create the table and `transform_queries.sql` to query insights.
3. Import the cleaned dataset into Power BI and build visuals like:
   - Revenue over time
   - Top products
   - Customer analysis

## Sample Data Fields
- OrderID, CustomerID, ProductName, Quantity, UnitPrice, OrderDate

---
