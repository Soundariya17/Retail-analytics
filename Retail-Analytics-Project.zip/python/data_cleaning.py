import pandas as pd

# Load raw data
df = pd.read_csv('../data/raw_sales_data.csv')

# Clean and transform
df['OrderDate'] = pd.to_datetime(df['OrderDate'])
df['Revenue'] = df['Quantity'] * df['UnitPrice']

# Save cleaned data
df.to_csv('../data/cleaned_sales_data.csv', index=False)
print("Data cleaned and saved successfully.")
