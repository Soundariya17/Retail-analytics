CREATE TABLE Sales (
    OrderID INT,
    CustomerID INT,
    ProductName VARCHAR(100),
    Quantity INT,
    UnitPrice FLOAT,
    OrderDate DATE,
    Revenue FLOAT
);
