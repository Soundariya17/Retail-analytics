-- Total revenue by month
SELECT DATE_TRUNC('month', OrderDate) AS Month, SUM(Revenue) AS TotalRevenue
FROM Sales
GROUP BY Month
ORDER BY Month;
